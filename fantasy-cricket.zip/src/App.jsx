import { useState } from "react";

const players = [
  // Team A (15 players)
  "Virat Kohli", "Rohit Sharma", "Shubman Gill", "KL Rahul", "Hardik Pandya",
  "Ravindra Jadeja", "Rishabh Pant", "Jasprit Bumrah", "Mohammed Shami",
  "Kuldeep Yadav", "Suryakumar Yadav", "Shreyas Iyer", "Ishan Kishan",
  "Bhuvneshwar Kumar", "Axar Patel",
  // Team B (15 players)
  "Joe Root", "Jos Buttler", "Ben Stokes", "Jonny Bairstow", "Moeen Ali",
  "Jofra Archer", "Mark Wood", "Chris Woakes", "Sam Curran", "Adil Rashid",
  "Harry Brook", "Dawid Malan", "Jason Roy", "Reece Topley", "Ollie Pope"
];

export default function FantasyCricket() {
  const [username, setUsername] = useState("");
  const [signedIn, setSignedIn] = useState(false);
  const [selected, setSelected] = useState([]);
  const [done, setDone] = useState(false);
  const [allTeams, setAllTeams] = useState([]);

  const togglePlayer = (player) => {
    if (selected.includes(player)) {
      setSelected(selected.filter((p) => p !== player));
    } else if (selected.length < 11) {
      setSelected([...selected, player]);
    }
  };

  const finishTeam = () => {
    if (selected.length === 11) {
      const newTeams = [...allTeams, { user: username, team: selected }];
      setAllTeams(newTeams);
      setDone(true);
    } else {
      alert("You must select 11 players before finishing!");
    }
  };

  if (!signedIn) {
    return (
      <div className="flex flex-col items-center justify-center h-screen">
        <h1 className="text-2xl font-bold mb-4">PLEASE SIGN IN</h1>
        <input
          type="text"
          placeholder="Enter your name"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          className="border p-2 rounded mb-4 w-64"
        />
        <button
          onClick={() => username.trim() && setSignedIn(true)}
          className="bg-blue-500 text-white px-4 py-2 rounded shadow"
        >
          Sign In
        </button>
      </div>
    );
  }

  if (done && allTeams.length === 2) {
    const team1 = allTeams[0].team;
    const team2 = allTeams[1].team;

    const commonPlayers = team1.filter((p) => team2.includes(p));
    const uniqueTeam1 = team1.filter((p) => !team2.includes(p));
    const uniqueTeam2 = team2.filter((p) => !team1.includes(p));

    return (
      <div className="p-6 max-w-3xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Results</h1>

        <h2 className="text-xl font-semibold mb-2">Common Players</h2>
        <div className="grid grid-cols-2 gap-2 mb-6">
          {commonPlayers.map((player) => (
            <div key={player} className="p-2 bg-yellow-100 rounded shadow">
              {player}
            </div>
          ))}
          {commonPlayers.length === 0 && (
            <p className="text-gray-500">No common players</p>
          )}
        </div>

        <div className="grid grid-cols-2 gap-6">
          <div>
            <h2 className="text-xl font-semibold mb-2">{allTeams[0].user}'s Unique Players</h2>
            {uniqueTeam1.map((player) => (
              <div key={player} className="p-2 bg-green-100 rounded shadow mb-2">
                {player}
              </div>
            ))}
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-2">{allTeams[1].user}'s Unique Players</h2>
            {uniqueTeam2.map((player) => (
              <div key={player} className="p-2 bg-blue-100 rounded shadow mb-2">
                {player}
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!done) {
    return (
      <div className="p-6 max-w-3xl mx-auto">
        <h1 className="text-2xl font-bold mb-2">Fantasy Cricket (Pick 11)</h1>
        <p className="mb-6 text-gray-600">Welcome, {username} 👋</p>

        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">Your Fantasy XI</h2>
          <div className="grid grid-cols-2 gap-2">
            {selected.map((player) => (
              <div key={player} className="p-2 bg-green-100 rounded shadow">
                {player}
              </div>
            ))}
            {selected.length === 0 && (
              <p className="text-gray-500">No players selected yet</p>
            )}
          </div>
        </div>

        <div>
          <h2 className="text-xl font-semibold mb-2">Available Players</h2>
          <div className="grid grid-cols-2 gap-2">
            {players.map((player) => (
              <button
                key={player}
                onClick={() => togglePlayer(player)}
                className={`p-2 rounded shadow flex justify-between items-center ${
                  selected.includes(player)
                    ? "bg-green-300"
                    : "bg-gray-100 hover:bg-gray-200"
                }`}
              >
                {player}
                <span className="ml-2 text-lg font-bold">+</span>
              </button>
            ))}
          </div>
        </div>

        <div className="mt-4 flex justify-between items-center">
          <p className="text-lg font-semibold">
            Selected: {selected.length} / 11
          </p>
          <button
            onClick={finishTeam}
            className="bg-blue-500 text-white px-4 py-2 rounded shadow"
          >
            Done
          </button>
        </div>
      </div>
    );
  }
}